1.0.0 / 2015-11-19
==================

  * Test cases

0.0.6 / 2015-07-16
==================

  * Whitelisted Origins (@CodeCommander)

0.0.5 / 2015-04-28
==================

  * Route Middleware

0.0.4 / 2015-04-14
==================

  * Prefligted vs Simple

0.0.3 / 2015-02-10
==================

  * psr-4 autoload

0.0.2 / 2015-02-09
==================

  * Support for preflight

0.0.1 / 2014-10-26
==================

 * First release
